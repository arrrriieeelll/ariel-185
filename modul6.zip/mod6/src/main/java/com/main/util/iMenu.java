package com.main.util;

public interface iMenu {
        void menu();
}
