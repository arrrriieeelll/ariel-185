import java.util.Scanner;
import javax.swing.plaf.synth.SynthScrollBarUI;

class user{ 
    void bookslist(){
        String buku1 = "cinta";
        String buku2 = "pantai";
        String buku3 = "samudra";
        String addressbuku1 = Integer.toHexString(System.identityHashCode(buku1));
        String addressbuku2 = Integer.toHexString(System.identityHashCode(buku2));
        String addressbuku3 = Integer.toHexString(System.identityHashCode(buku3)); 
        System.out.println("==================================================================================================");
        System.out.println("|| No.\t||\tid buku\t\t||Nama buku\t||Author\t||Category\t||\tStock\t||");
        System.out.println("==================================================================================================");
        System.out.println("|| 1. \t||\t"+addressbuku1+"\t||cinta\t\t||Author\t||cinta\t\t||\t5\t||");
        System.out.println("|| 2. \t||\t"+addressbuku2+"\t||pantai\t||Author\t||suasana\t||\t1\t||");
        System.out.println("|| 3. \t||\t"+addressbuku3+"\t||samudra\t||Author\t||healing\t||\t2\t||");
        System.out.println("==================================================================================================");
    }
}

class student{
    String nim;
    int books;
    int books2;
    int input1;
    int lamaBooks;
    int bukuKosong = '0';

    String buku1 = "cinta";
    String buku2 = "pantai";
    String buku3 = "samudra";
    String addressbuku1 = Integer.toHexString(System.identityHashCode(buku1));
    String addressbuku2 = Integer.toHexString(System.identityHashCode(buku2));
    String addressbuku3 = Integer.toHexString(System.identityHashCode(buku3));

    Scanner key = new Scanner(System.in);

    void student(){
        System.out.print("enter your nim : ");
        nim = key.nextLine();
        System.out.println("\n");

        System.out.println("=== Student menu ===");
        System.out.println("1. pinjam buku dan lihat buku terpinjam ");
        System.out.println("2. kembalikan buku");
        System.out.println("3. exit");
        System.out.print("pilihan anda : ");
        input1 = key.nextInt();
        switch (input1) {
            case 1:
                displaybooks();
                student();
                break;
            case 2:
                
                break;
            case 3:
                student();
                break;
               
        }
    }


    void displayinfo(){ // menampilka data mahasiswa 

    }


    void showBrowedBooks(){ 
        user user1 = new user();
        System.out.println("buku yang tersedia :\n");
        
        user1.bookslist();

        System.out.print("\npilih buku yang ingin di pinjam : ");
        books = key.nextInt();
        System.out.println("\n");
        System.out.println("==== buku sudah berhasil di pinjam ====\n\n");

        System.out.println("berapa lama buku akan dipinjam ? (max 14 hari)");
        System.out.print("input lama : ");
        lamaBooks = key.nextInt();
    }



   
    void displaybooks(){
        showBrowedBooks();
        System.out.println("=====================");
        System.out.println("1. lihat buku");
        System.out.println("99. EXIT");
        System.out.println("=====================");
        System.out.print("pilih opsi diatas : ");
        books2 = key.nextInt();
        System.out.println("\n\n");

        switch (books2) {
            case 1:
            switch (books) {
                case 1:
                    System.out.println("buku yang anda pinjam = ");
                    System.out.println("##################################################");
                    System.out.println("nama buku : "+buku1+ "\tid buku : " +addressbuku1);
                    System.out.println("##################################################");
                    System.out.println("\n\n\n");
                    break;
                case 2:
                    System.out.println("buku yang anda pinjam = ");
                    System.out.println("##################################################");
                    System.out.println("nama buku : "+buku2+ "\tid buku : " +addressbuku2);
                    System.out.println("##################################################");
                    System.out.println("\n\n\n");
                    break;
                case 3:
                    System.out.println("buku yang anda pinjam = ");
                    System.out.println("##################################################");
                    System.out.println("nama buku : "+buku3+ "\tid buku : " +addressbuku3);
                    System.out.println("##################################################");
                    System.out.println("\n\n\n");
                    break;
            }
            
                break;
            case 99:
                
                return;
        }
        
    }

    void logout(){ //method untuk logout

    }
}



class admin{
    student hasilStudent = new student();
    Scanner key = new Scanner(System.in);
    String bookld, title, author, category;
    int stock, duration, input3;

    String adminUser, adminPassword;

    String name;
    String faculty;
    String nim;
    String programStudi;


    void isAdmin(){
        System.out.print("enter your username (admin) :");
        adminUser = key.nextLine();
        System.out.print("enter your password (admin) :");
        adminPassword = key.nextLine();
        System.out.println("\n");

        if (adminUser.equals("admin")){
            if(adminPassword.equals("admin")){
                System.out.println("anda berhasil masuk");
            }else{
                System.out.println("###########################");
                System.out.println("# user dan password salah #");
                System.out.println("###########################\n");

                System.out.println("ulangi lagi :");
                isAdmin();
            }
            displayAdmin();
        }
    }

    void displayAdmin(){

                System.out.println("====== admin menu =====");
                System.out.println("1. add student ");
                System.out.println("2. add book ");
                System.out.println("3. display registered ");
                System.out.println("4. display avilabel books ");
                System.out.println("5. logout ");
                System.out.print("choose option (1 - 5 ) :");
                input3 = key.nextInt();



        switch (input3) {
            case 1:
                addStudent();
                break;
            case 2:
                
                break;
            case 3:
                displayStudent();
                break;
            case 4:
                
                break;
            case 5:
                System.out.println("thanks for entering the program");
                return;
        }
    }

    void addStudent(){

        
        System.out.println("add your name :");
        name = key.nextLine();
        
        System.out.print("add your nim :");
        nim = key.nextLine();
        int length = String.valueOf(nim).length();
        while(length != 15) {
            System.out.println("Nim max 15!!!");
            System.out.print("add your nim: ");
            nim = key.nextLine();
        }

        System.out.print("add your faculty :");
        faculty = key.nextLine();

        System.out.print("add your studi :");
        programStudi = key.nextLine();  

        displayAdmin();
    }

    void inputBook(){ //membuat buku baru
        
    }

    void displaybook(){ //melihat hasil perubahan buku

    }

    void displayStudent(){

            System.out.println("nama : " + name);
            System.out.println("nim : " + nim);
            System.out.println("faculty : " + faculty);
            System.out.println("program studi : " + programStudi);


            displayAdmin();
    }

    
}

class book{
        public String bookld;
        public String title;
        public String author;
        public String category;
        public int stock;
        public int duration;

        book(String booklds, String title, String author, String category){
            this.bookld = bookld;
            this.title = title;
            this.author = author;
            this.category = category;
        }

        public void setbookld(String bookld){
                this.bookld = bookld;
        }

        public void settitle(String title){
                this.title = title;
        }
        public void setauthor(String author){
                this.author = author;
        }
        public void setcategory(String category){
                this.category = category;
        }

        public String getbookld(){
                return bookld;
        }
        public String gettitle(){
                return this.title;
        }
        public String getauthor(){
                return this.author;
        }
        public String getcategory(){
                return this.category;
        }

}
// class HistoryBook extends book{

//     Scanner key = new Scanner(System.in);
//        public HistoryBook(String bookld){
//             super(bookld);

//         }

//         void history(){
//             System.out.println("enter book title : ");
//             this.title = key.nextLine();
//             System.out.println("enter author : ");
//             this.author = key.nextLine();
//             System.out.println("enter the stock : ");
//             this.stock = key.nextInt();
//         }
// }
// class storybook extends book{
//     Scanner key = new Scanner(System.in);
//     public storybook(String bookld){
//          super(bookld);

//      }

//      void storybook(){
//          System.out.println("enter book title : ");
//          this.title = key.nextLine();
//          System.out.println("enter author : ");
//          this.author = key.nextLine();
//          System.out.println("enter the stock : ");
//          this.stock = key.nextInt();
//      }
// }
// class textBook extends book{
    
//     Scanner key = new Scanner(System.in);
//     public textBook(String bookld){
//          super(bookld);

//      }

//      void textBook(){
//          System.out.println("enter book title : ");
//          this.title = key.nextLine();
//          System.out.println("enter author : ");
//          this.author = key.nextLine();
//          System.out.println("enter the stock : ");
//          this.stock = key.nextInt();
//      }
// }

public class main{
    public static void main(String[] args){
        Scanner key = new Scanner(System.in);
        int input;
        student hasilStudent = new student();
        admin hasilAdmin = new admin();

        System.out.println("1. login as student");
        System.out.println("2. login as admin");
        System.out.println("3. admin");
        System.out.print("choose option(1 - 3) : ");
        input = key.nextInt();


    switch (input) {
        case 1:
            hasilStudent.student();
            break;
        case 2:
            hasilAdmin.isAdmin();
            break;
        case 3:
            
            break;
    
        default:
            break;
    }
    }
}